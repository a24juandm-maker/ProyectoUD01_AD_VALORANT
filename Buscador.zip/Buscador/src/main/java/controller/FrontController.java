/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import controller.user.LoginController;
import controller.user.RegisterController;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import model.Pj;
import model.Pjs;
import model.Users;
import view.MainJFrame;
import view.user.UserJDialog;

/**
 *
 * @author W10-Portable
 */
public class FrontController {

    private MainJFrame view;
    private Pjs dataPjs;
    private Users dataUsuarios;

    public FrontController(MainJFrame view, Pjs data, Users dataUsuarios) {
        this.view = view;
        this.dataPjs = data;
        this.dataUsuarios = dataUsuarios;
        this.view.setRegisterJButtonActionListener(this.getRegisterJButtonActionListener());
        this.view.setLoginJButtonActionListener(this.getLoginJButtonActionListener());
        this.view.setShowJButtonActionListener(this.getShowJButtonActionListener());
        this.view.setReturnJButtonActionListener(this.getReturnJButtonActionListener());
        this.view.setSearchTextFieldKeyListener(this.getSearchTextFieldKeyListener());
        this.view.setRoleComboJComboBoxActionListener(this.getRoleComboJComboBoxActionListener());

        
        view.setImageTitle(this.addTitleImage());
        initComboBox();
        
        List<Pj> dataPj = dataPjs.getListPj();
        addPjButtons(dataPj);
        //searchBar();
    }

    public void addPjButtons(List<Pj> dataPjs) {
        int tamanhoLista = dataPjs.size();
        System.out.println("Tenemos este numero de personajes " + tamanhoLista);


        int columnas = 6;

        // Calcular el número de filas necesarias, matematicas del infierno
        int filas = (int) Math.ceil(tamanhoLista / (double) columnas);
        int gap = 10;
        int contador = 0;
        int tamanhoBoton = 100;
        
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if (contador < tamanhoLista) {
                    
                    Pj boton = (Pj) dataPjs.get(contador);
                    
                    boton.setLayout(null);
                    
                    int xPos = j*(tamanhoBoton + gap);
                    int yPos = i*(tamanhoBoton + gap);
                    boton.setBounds(xPos, yPos, tamanhoBoton, tamanhoBoton);
                    
                    ImageIcon careto = boton.getDisplayImagePj();
                    Image image = careto.getImage();

                    //Tratamiento Imagen
                    Image imageRedimensity = image.getScaledInstance(boton.getWidth(), boton.getHeight(), Image.SCALE_SMOOTH);

                    // Creacion  ImageIcon redimensionado
                    ImageIcon imagenBotonFinal = new ImageIcon(imageRedimensity);
                    
                    boton.setIcon(imagenBotonFinal);
                    
                    boton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            System.out.println("presiono agente, muestro imagen");
                            view.addSetImageDisplayLabel(boton.getGreatPjImage());
                        }
                    });
                    
                    String nameButton = boton.getName();
                    view.addButtonPj(boton,nameButton);
                    contador++;
                    

                }
                else{
                    JButton emptyButton = new JButton();
                    emptyButton.setEnabled(false); // Lo deshabilitamos
                    view.add(emptyButton);
                }
            }
        }
        view.revalidate();
        view.repaint();
        //this.view.addButtonPj(button);
    }
    
    private void initComboBox() {
        for (String p : dataPjs.getListRole()) {
            this.view.addItemRoleComboBox(p);

        }
    }

    private ActionListener getRegisterJButtonActionListener(){
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UserJDialog viewLogin = new UserJDialog(view,true);
                RegisterController lc = new RegisterController(viewLogin,dataUsuarios,FrontController.this);
                
                viewLogin.setTextLoginJButton("Registrar");
                viewLogin.setTextLoginTitleJLabel("Register");
                
                viewLogin.setVisible(true);
            }
        };
        return al;
    }

    private ActionListener getLoginJButtonActionListener(){
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UserJDialog viewLogin = new UserJDialog(view,true);
                LoginController lc = new LoginController(viewLogin,dataUsuarios,FrontController.this);
                
                viewLogin.setTextLoginJButton("Logear");
                viewLogin.setTextLoginTitleJLabel("Login");
                
                viewLogin.setVisible(true);
            }
        };
        return al;
    }

    private ActionListener getShowJButtonActionListener(){
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Boton Ver");
            }
        };
        return al;
    }

    private ActionListener getReturnJButtonActionListener(){
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Boton Volver");
            }
        };
        return al;
    }
    
    private KeyListener getSearchTextFieldKeyListener(){
        KeyListener kl = new KeyListener() {
            @Override
            public void keyTyped(KeyEvent ke) {
                
            }

            @Override
            public void keyPressed(KeyEvent ke) {
                
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                String searchText = view.getSearchTextField();
                
                List<JButton> listaBotones = view.getButtonsPanelPjs();
                if (!searchText.isEmpty()) {
                    for (JButton botonPj : listaBotones) {
                        if(!botonPj.getName().toUpperCase().contains(searchText.toUpperCase()) || !botonPj.getName().toLowerCase().contains(searchText.toLowerCase())){
                            botonPj.setEnabled(false);
                        } else {
                            botonPj.setEnabled(true);
                        }
                    }
                } else {
                    for(JButton botonPj : listaBotones){
                        botonPj.setEnabled(true);
                    }
                }
            }
        };
        return kl;
    }
    
    private ActionListener getRoleComboJComboBoxActionListener(){
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Pj> dataPj = dataPjs.getListPj();
                List<Pj> rolDataPj = new ArrayList<>();
                Object selectedItem = view.getItemRoleComboJComboBox();
                if(!selectedItem.equals("Rol")){
                    for (Pj personaje : dataPj) {
                        if (personaje.getRole().equals(selectedItem.toString())) {
                            rolDataPj.add(personaje);
                        }
                    }
                    view.clearPanelPj();
                
                    addPjButtons(rolDataPj);
                } else {
                    view.clearPanelPj();
                    addPjButtons(dataPj);
                }
            }
        };
        return al;
    }

    private ImageIcon addTitleImage() {
        ImageIcon titleImage = null;
        try {

            String urlImage = "https://esportsbureau.com/wp-content/uploads/2020/04/valorant.jpg";

            //Cargar Imagen Titulo de internet
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(urlImage))
                    .build();

            //Cliente HTTP obtener imagen
            HttpClient client = HttpClient.newHttpClient();
            HttpResponse<InputStream> response;
            response = client.send(request,
                    HttpResponse.BodyHandlers
                            .ofInputStream());

            //Leemos Flujo Imagen
            InputStream inputStream = response.body();
            Image image = ImageIO.read(inputStream);

            //Tratamiento Imagen
            Image imageRedimensity = image.getScaledInstance(1000, 220, Image.SCALE_SMOOTH);

            // Creacion  ImageIcon redimensionado
            titleImage = new ImageIcon(imageRedimensity);

        } catch (IOException ex) {
            System.out.println("Fallo entrada/salida lectura  imagen");
        } catch (InterruptedException ex) {
            Logger.getLogger(FrontController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return titleImage;
    }
}
